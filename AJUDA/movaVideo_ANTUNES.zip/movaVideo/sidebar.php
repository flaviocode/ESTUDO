<div class="col-md-4 sidebar">
      <?php 
       if ( is_active_sidebar('sidebar-internas') ) {
        dynamic_sidebar('sidebar-internas');
        }
      ?>
</div>