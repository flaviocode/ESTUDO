<? $home = get_template_directory_uri(); ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>

	

	<meta charset="UTF-8">

    <?php wp_head(); ?> 

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	
	<!-- usar a função que pega o diretório do tema e completar com o caminho de onde está o tema -->
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/compiler/css/reset.css">

	<!-- css do bootstrap -->
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/compiler/css/bootstrap/bootstrap.css">

	<!-- galeria de fontes -->
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/compiler/css/fontawesome-all.min.css">
	
	<title> <?php bloginfo('name') ?>  </title>
</head>
<body>