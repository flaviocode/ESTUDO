<?php
// pegar o arquivo marca header
require get_template_directory() . '/inc/marca.php';
?> 