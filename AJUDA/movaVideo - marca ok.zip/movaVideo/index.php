<?php get_header(); ?>
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
CAROUSEL E LISTAS
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<div class="container">
		<div class="row">

			<!-- Carousel -->
			<div class="col-lg-8 col-md-12 slide-noticia mt-1">

				<!-- Div principal do carousel -->
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

					<!-- Marcadores de qual slide está -->
					<ol class="carousel-indicators">
						<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
						<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
					</ol>

					<!-- Div para organizar todos os carousel -->
					<div class="carousel-inner">

						<!-- Caousel 1 -->
						<div class="carousel-item active">
							<img class="d-block w-100" src="<?php bloginfo('template_url'); ?>/images/image-1.png" alt="First slide">
							<div class="carousel-caption d-none d-md-block">
								<h5>IMAGEMD E UMA CAMERA</h5>
							</div>
						</div>

						<!-- Caousel 2 -->
						<div class="carousel-item">
							<img class="d-block w-100" src="<?php bloginfo('template_url'); ?>/images/image-2.png" alt="Second slide">
							<div class="carousel-caption d-none d-md-block">
								<h5>UM MICROFONE</h5>
							</div>
						</div>

						<!-- Caousel 3 -->
						<div class="carousel-item">
							<img class="d-block w-100" src="<?php bloginfo('template_url'); ?>/images/image-3.png" alt="Third slide">
							<div class="carousel-caption d-none d-md-block">
								<h5>TRANSMISSÃO PROFICIONAL</h5>
							</div>
						</div>

					</div><!-- Fim da div para organizar todos os carousel -->

					<!-- Botões avançar e retroceder -->
					<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
						<span class="carousel-control-prev-icon" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
						<span class="carousel-control-next-icon" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div><!-- fim da div principal do carousel -->
			</div><!-- fim do carousel -->

			<!-- Lista mais vistos e comentacos -->
			<div class="col-lg-4 col-md-12 itens-destaque mt-1">

				<!-- Guias -->
				<nav>
					<div class="nav nav-tabs" id="nav-tab" role="tablist">
						<a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#maisvistos" role="tab" aria-controls="maisvistos" aria-selected="true">Mais Vistos</a>
						<a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#maiscomentados" role="tab" aria-controls="nav-profile" aria-selected="false">Mais Comentados</a>
					</div>
				</nav>

				<!-- Div para conter todo o conteúdo das guias -->
				<div class="tab-content" id="nav-tabContent">

					<!-- conteúdo da gui maisvistos -->
					<div class="tab-pane fade show active" id="maisvistos" role="tabpanel" aria-labelledby="nav-home-tab">

						<ul class="list-group">

							<li class="list-group-item d-flex justify-content-between align-items-center">
								Cras justo odio
								<span class="badge badge-primary badge-pill ">90</span>
							</li>

							<li class="list-group-item d-flex justify-content-between align-items-center">
								Dapibus ac facilisis in
								<span class="badge badge-primary badge-pill ">90</span>
							</li>

							<li class="list-group-item d-flex justify-content-between align-items-center">
								Morbi leo risus
								<span class="badge badge-primary badge-pill ">90</span>
							</li>

						</ul>
					</div>

					<!-- conteúdo da gui maiscomentados -->
					<div class="tab-pane fade" id="maiscomentados" role="tabpanel" aria-labelledby="nav-profile-tab">

						<ul class="list-group">

							<li class="list-group-item d-flex justify-content-between align-items-center">
								Justo odio
								<span class="badge badge-primary badge-pill ">90</span>
							</li>

							<li class="list-group-item d-flex justify-content-between align-items-center">
								Facilisis in
								<span class="badge badge-primary badge-pill">80</span>
							</li>

							<li class="list-group-item d-flex justify-content-between align-items-center">
								Leo risus
								<span class="badge badge-primary badge-pill">60</span>
							</li>

						</ul>

					</div>
				</div>

				<!-- Imagem que está abaixo do das guias -->
				<img src="<?php bloginfo('template_url'); ?>/images/image-4.jpg" class="img-fluid img-thumbnail mt-1" alt="Responsive image">
				
			</div>
		</div>
	</div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->


<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
POR DENTRO DOS CAMPOS e LUTAS
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<div class="jumbotron jumbotron-fluid mt-3">
		<div class="container"><!-- container -->
			<div class="row title-box"><!-- Primeira linha-->

				<!-- Barra de título Por dentro dos campos -->
				<div class="col-md-9"><h4>Por dentro dos campos</h4></div>

				<!-- Barra de título Lutas -->
				<div class="col-md-3 d-none d-md-block"><h4>Lutas</h4></div>
			</div><!-- fim primeira linha -->

			<div class="row"><!-- Segunda linha -->

				<!-- Por dentro dos campos -->
				<div  class="col-md-3 item-futebol" >

					<a href="#" >
						<img src="<?php bloginfo('template_url'); ?>/images/image-4.jpg" class="img-fluid mt-1" alt="Responsive image">
					</a>
					<span>Campo Extra</span>
					<h1>
						<a href="#">Título do post para a categoria futebol</a>
					</h1>

				</div>

				<div  class="col-md-3 item-futebol" >

					<a href="#" >
						<img src="<?php bloginfo('template_url'); ?>/images/image-4.jpg" class="img-fluid mt-1" alt="Responsive image">
					</a>
					<span>Campo Extra</span>
					<h1>
						<a href="#">Título do post para a categoria futebol</a>
					</h1>

				</div>

				<div  class="col-md-3 item-futebol" >

					<a href="#" >
						<img src="<?php bloginfo('template_url'); ?>/images/image-4.jpg" class="img-fluid mt-1" alt="Responsive image">
					</a>
					<span>Campo Extra</span>
					<h1>
						<a href="#">Título do post para a categoria futebol</a>
					</h1>

				</div><!-- fim de por dentro dos campos -->

				<!-- Lutas -->
				<div  class="col-md-3 item-futebol" >

					<a href="#" >
						<img src="<?php bloginfo('template_url'); ?>/images/image-4.jpg" class="img-fluid mt-1" alt="Responsive image">
					</a>
					<span>Campo Extra</span>
					<h1>
						<a href="#">Título do post para a categoria futebol</a>
					</h1>

				</div><!-- Lutas -->

			</div><!-- fim segunda linha-->
		</div><!-- fim container -->
	</div><!-- fim 1 -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->


<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
MUNDO DOS GAMES E VIDEO DA SEMANA
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
     <div class="jumbotron jumbotron-fluid bg-white">
          <div class="container">

               <div class="row title-box"><!-- Primeira linha-->
                    <!-- Barra de título Mundo dos Games -->
                    <div class="col-md-7"><h4>Mundo dos Games</h4></div>

                    <!-- Barra de título Vídeo da semana -->
                    <div class="col-md-5"><h4>Vídeo da semana</h4></div>
               </div><!-- fim primeira linha -->

               <!-- Linha do conteúdo -->
               <div class="row">
                    <!-- Posts a esquerda -->
                    <div class="col-md-7" id="post-games">

                         <!-- post 1 -->
                         <ul class="list-unstyled">
                              <li class="media">
                                   <img class="mr-3 img-fluid" src="<?php bloginfo('template_url'); ?>/images/image-5.png" alt="Generic placeholder image">
                                   <div class="media-body">
                                        <h5 class="mt-0 mb-1"><a href="#">Scelerisque</a></h5>
                                        <span>Campo extra</span>
                                        <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fuscea.</p>
                                   </div>
                              </li>
                         </ul><!-- fim post 1 -->

                         <!-- post 2 -->
                         <ul class="list-unstyled">
                              <li class="media">
                                   <img class="mr-3" src="<?php bloginfo('template_url'); ?>/images/image-5.png" alt="Generic placeholder image">
                                   <div class="media-body">
                                        <h5 class="mt-0 mb-1"> <a href="#">Nulla vel metus scelerisque</a> </h5>
                                        <span>Campo extra</span>
                                        <p>Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fuscea.</p>
                                   </div>
                              </li>
                         </ul><!-- fim post 2 -->

                    </div><!-- fim Posts a esquerda -->

                    <!-- vídeo da semana -->
                    <div class="col-md-5" id="video-home">
                         <div class="embed-responsive embed-responsive-16by9">
                              <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/gMtXLYWhbVw" allowfullscreen></iframe>
                         </div>
                    </div>
               </div>
          </div>
     </div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->

<?php get_footer(); ?>