
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
RODAPÉ
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<div class="jumbotron jumbotron-fluid bg-dark mb-0">
          <div class="container">
               <div class="row">
                    <!-- coluna 1 -->
                    <div class="col-md-3 mt-3">
                         <div class="card card-footer-text">


                              <div class="card-body card-text">
                                   <H5>Lorem ipsum</H5>
                                   <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui eius ullam numquam odit itaque perferendis tempore voluptatum perspiciatis! Assumenda, esse ipsa? Sapiente deserunt sint voluptate ducimus.</p>
                                   <p class="card-text">Amet consectetur adipisicing elit.</p>
                              </div>
                         </div>
                    </div><!-- fim coluna 1 -->

                    <!-- coluna 2-->
                    <div class="col-md-5 mt-3">
                         <div class="row">
                              <div class="col-md-6">
                                   <ul class="list-group list-group-flush links-footer">
                                        <li class="list-group-item"><a href="#">Cras justo odio</a></li>
                                        <li class="list-group-item"><a href="#">Dapibus ac facilisis in</a></li>
                                        <li class="list-group-item"><a href="#">Morbi leo risus</a></li>
                                        <li class="list-group-item"><a href="#">Porta ac consectetur ac</a></li>
                                        <li class="list-group-item"><a href="#">Vestibulum at eros</a></li>
                                        <li class="list-group-item"><a href="#">Cras justo odio</a></li>
                                        <li class="list-group-item"><a href="#">Dapibus ac facilisis in</a></li>
                                   </ul>
                              </div>
                              <div class="col-md-6">
                                   <ul class="list-group list-group-flush links-footer">
                                        <li class="list-group-item"><a href="#">Cras justo odio</a></li>
                                        <li class="list-group-item"><a href="#">Dapibus ac facilisis in</a></li>
                                        <li class="list-group-item"><a href="#">Morbi leo risus</a></li>
                                        <li class="list-group-item"><a href="#">Porta ac consectetur ac</a></li>

                                   </ul>
                              </div>
                         </div>
                    </div><!-- fim coluna 2 -->

                    <!-- fim coluna 3 -->
                    <div class="col-md-4 mt-3">
                    <div class="card card-footer-text">

                              <div class="card-body card-img">
                                   <img src="<?php bloginfo('template_url'); ?>/images/image-1.png" class="img-fluid" alt="Responsive image">
                              </div>
                         </div>
                    </div><!-- fim coluna 3 -->
               </div><!-- fim row -->

               <div class="row">
                    <div class="col-md-12 mt-3">

                         <div class="card card-footer-text">

                              <div class="card-body card-img">
                                   <div class="embed-responsive embed-responsive-16by9">
                                   <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1304.7074719221857!2d-43.46345797562569!3d-22.981675453699285!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9bdd754cd0791b%3A0x69096a1fed493087!2sDegust!5e0!3m2!1spt-BR!2sbr!4v1524682774218" width="1200" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>

                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </div>


<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
MODAL DE LOGIN
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<!-- Button trigger modal -->
	<div class="modal fade" id="modalLogin" tabindex="-1" role="dialog" aria-labelledby="modalLogin" aria-hidden="true">
		<div class="modal-dialog" role="document">

			<div class="modal-content">

				<div class="modal-header">
					<h5 class="modal-title" id="modalLoginLabel">Login</h5>

					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>

				</div>

				<div class="modal-body">

					<!-- Conteúdo do Modal -->
					<form>
						<div class="form-group">
							<label for="exampleInputEmail1">Email</label>
							<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
						</div>

						<div class="form-group">
							<label for="exampleInputPassword1">Senha</label>
							<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
						</div>
					</form>
					<!-- fim do conteúdo do modal -->

				</div>

				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
					<button type="button" class="btn btn-primary">Logar</button>
				</div>

			</div>
		</div>
	</div>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->














	<!-- SCRIPS EXTERNOS -->
	<div>
		<!-- jQuery, Popper.js, Bootstrap JS -->
		<script src="<?php bloginfo('template_url'); ?>/node_modules/jquery/dist/jquery.min.js"></script>
		<script src="<?php bloginfo('template_url'); ?>/node_modules/popper.js/dist/umd/popper.js"></script>
		<script src="<?php bloginfo('template_url'); ?>/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
	</div>
</body>
</html>