<!doctype html>
<html lang="pt-br">
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
HEADE
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
<head>
	<!-- meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS e fontawesome -->
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/compiler/bootstrap/bootstrap.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/compiler/icones/fontawesome-all.min.css">

	
	<!-- Folha de estilo -->
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/estilo.css">

	<title><?php bloginfo('name'); ?></title>
</head>
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->


<body>
<!--  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
HEADERR
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->
	<div class="header">
		<div class="container">
			<div class="row">

				<!-- Loogo do site -->
				<div class="col-md-3 logo">

					<a href="<?php bloginfo('home'); ?>">
						<img class="img-fluid" src="<?php echo get_theme_mod('m1_logo'); ?>" alt="Mova Vídeos" title="Mova Vídeos">
					</a>

				</div>



				<!-- Barra de navegação -->
				<div class="col-md-9">
				
					<nav class="navbar navbar-expand-lg navbar-light bg-light">
						
						<!-- Navbar -->
						<a class="navbar-brand d-lg-none" href="#" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false">Navegação do site</a>

						<!-- botao hanburger -->
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="navbar-toggler-icon"></span>
						</button>

						<!-- Ítens de menu -->
						<div class="collapse navbar-collapse" id="navbarSupportedContent">

							<!-- links da página -->
							<ul class="navbar-nav mr-auto">

								<li class="nav-item mr-2">
									<a class="nav-link" href="#">Notícias</a>
								</li>


								<!-- menu dropdown -->
								<li class="nav-item dropdown mr-2">

									<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										Vídeos
									</a>

									<div class="dropdown-menu" aria-labelledby="navbarDropdown">
										<a class="dropdown-item" href="#">Luta</a>
										<a class="dropdown-item" href="#">Futebol</a>
										<a class="dropdown-item" href="#">Games</a>
									</div>
								</li>
								
								<li class="nav-item mr-2">
									<a class="nav-link" href="#">Contatos</a>
								</li>

							</ul>


							<!-- formdepesquisa -->
							<form class="form-inline my-2 my-lg-0">
								<input class="form-control mr-sm-2" type="search" placeholder="Digite aqui sua busca..." aria-label="Search">
								<button class="btn btn-outline-success my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
							</form>


							<!-- botao de login -->
							<ul class="navbar-nav">
								<li class="nav-item">
									<a class="nav-link" href="#" data-toggle="modal" data-target="#modalLogin"><i class="fas fa-sign-in-alt"></i></a>
								</li>
							</ul>
						</div>
					</nav>

				</div><!-- fim da div col-md-9 -->
				
			</div><!-- fim da div row -->
		</div><!-- fim da div container -->
	</div><!-- fim da div header -->
<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -->